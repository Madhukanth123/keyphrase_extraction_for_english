Bible Chapter Themes

Goal: Identify the common, simple themes in a chapter, such that those themes can be compared (Venn diagram style) 
with other chapters.
* Extra points awarded for working in key phrases


Process
1) Find keywords
2) Rank by tfidf.
    * How do I work in ranking based on relationships to other key words?
3) Find key phrases
4) How to mix them in?
    * Use a weighted tfidf
    * Add to key single-words (to clarify meaning)


Output: 
1) Wordcloud for any section of scripture
2) Find overlap between chapters
    * Find textually similar chapters, no matter where they are.
3) Across scripture, graph words / themes
    * Imagine a moving graph where words pop in and out at the right level based on how often they appear.




Ideas:
* Add relationship ranking
* Count 1st occurrence of phrase in the document. Terms that tend to appear at the start or at the end 
of a document are more likely to be keyphrases.
* Length of phrase is also effective factor, works on defining keyphrase. It might be single word, two word or more word combination. It can be controlled at development time with KEA API.
Node degree of a candidate phrase is the number of phrases in the candidate set that are semantically related to this phrase. This is computed with the help of the thesaurus. Phrases with high degree are more likely to be keyphrases.

Sites:
* http://www.nzdl.org/Kea/
* http://www.cs.waikato.ac.nz/~ml/publications/2005/chap_Witten-et-al_Windows.pdf
* http://stackoverflow.com/questions/25109001/phrase-extraction-algorithm-for-statistical-machine-translation
* http://web.eecs.umich.edu/~mihalcea/papers/mihalcea.emnlp04.pdf
* 