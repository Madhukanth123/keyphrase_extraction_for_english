"""
source: x_spacy_basics.py
from: https://github.com/cytora/pycon-nlp-in-10-lines/blob/master/00_spacy_intro.ipynb
"""

import spacy                         # See "Installing spaCy"
nlp = spacy.load('en')               # You are here.

doc = nlp(u'Hello, world! A three sentence document.\nWith new lines...\nFor God so loved the world that He gave his '
          u'only begotten son, that whosever believes in him shall not perish but have everlasting life.')


# print("\n*** 1) Get 1ST TOKEN of document.***")
# token = doc[0]
# print(token)
#
# print("\n*** 2) Print SENTENCES (1 per line)***")
# for sent in doc.sents:
#     print(sent)

# print("\n*** 3) For each token, print corresponding PART OF SPEECH tag***")
# # print(list((w.text, w.pos_) for w in doc)) # See "Doc, Span and Token"
# for token in doc:
#     print('{} - {}'.format(token, token.pos_))

print("\n*** 3a) PRINT NOUNS based on POS***")
# token.nbor
kp = [token.lemma_ + ' ' + token[0].nbor() for token in doc if token.pos_ == "NOUN" or token.pos_ == "VERB"]
print(kp)


token_count = doc.__len__()

# def tokens_to_root(tkn):
#     """
#     Walk up the syntactic tree, collecting tokens to the root of the given `token`.
#     :param tkn: Spacy token
#     :return: list of Spacy tokens
#     """
#     tokens_to_r = []
#     while tkn.head is not tkn:
#         tokens_to_r.append(tkn)
#         tkn = tkn.head
#         tokens_to_r.append(tkn)
#
#     return tokens_to_r
#
# print("\n*** 4) Print each token's PATH TO THE ROOT***")
# for token in doc:
#     print('{} --> {}'.format(token, tokens_to_root(token)))
#
# print("\n*** 5) Print DEPENDENCY LABELS of the tokens***")
# for token in doc:
#     print('-> '.join(['{}-{}'.format(dependent_token, dependent_token.dep_) for dependent_token in tokens_to_root(token)]))
#
#
# print("\n*** 6) Print all NAMED ENTITIES with named entity types***")
# doc_2 = nlp(u"I went to Paris where I met my old friend Jack from uni.")
# for ent in doc_2.ents:
#     print('{} - {}'.format(ent, ent.label_))
#
#
# print("\n*** 7) Print NOUN CHUNKS for doc_2")
# print([chunk for chunk in doc_2.noun_chunks])
#
#
# print("\n*** 8) For every token, print LOG-PROBABILITY OF THE WORD, estimated from counts from a large corpus***")
# for token in doc_2:
#     print(token, ',', round(token.prob, 2))
#
#
# print("\n*** 9) CALCULATE SIMILARITY between 'apples' and 'oranges' and 'boots' and 'hippos'")
# doc = nlp(u"Apples and oranges are similar. Boots and hippos aren't.***")
# apples = doc[0]
# oranges = doc[2]
# boots = doc[6]
# hippos = doc[8]
# print(round(apples.similarity(oranges), 2))
# print(round(boots.similarity(hippos), 2))
#
# print("\n*** 10) Print similarity between sentence and word 'fruit'***")
# apples_sent, boots_sent = doc.sents
# fruit = doc.vocab[u'fruit']
# print(apples_sent.similarity(fruit))
# print(boots_sent.similarity(fruit))
