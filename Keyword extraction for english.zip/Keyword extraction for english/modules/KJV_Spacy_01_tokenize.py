"""
source: 01_tokenize.py
from:
author: david richards
date: 2017-01-25
"""

# IMPORTS
import logging
import os
from collections import Counter

import gensim
import spacy
import textacy
from gensim import corpora, models, similarities


logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)


# GLOBALS
nlp = spacy.load('en')
FILE_NAME = 'gen1.txt'
FILE_DIR = os.path.expanduser('~/Documents/Coding/KJV_Spacy/SourceText/')
MODEL_DIR = os.path.expanduser('~/Documents/Coding/KJV_Spacy/Models/')

def main():
    # Process `text` with Spacy nlp Parser
    with open(FILE_DIR + FILE_NAME, 'r') as file:
        text = file.read()
        # TODO: what are thee file options? readlines, decode(utf-8)?

    # text = read_file(FILE_DIR + FILE_NAME)
    doc = nlp(text)

    texts = [[str(word) for word in sent] for sent in doc.sents]
    dictionary = gensim.corpora.Dictionary(texts)

    s = "the buck stops here"

    dictionary.save(MODEL_DIR + 'gen1.dict')
    dictionary.save_as_text(MODEL_DIR + 'gen1_dict.txt')

    corpus = [dictionary.doc2bow(text) for text in texts]
    tfidf = models.TfidfModel(corpus)


    # keywords = Counter()
    # for chunk in doc.noun_chunks:
    #     if nlp.vocab[chunk.lemma_].prob < - 8:  # probability value -8 is arbitrarily selected threshold
    #         keywords[chunk.lemma_] += 1
    #
    # print(keywords.most_common(20))


    # Iterate over base NPs, e.g. "all their good ideas"
    # for np in doc.noun_chunks:
    #     # Only keep adjectives and nouns, e.g. "good ideas"
    #     while len(np) > 1 and np[0].dep_ not in ('amod', 'compound'):
    #         np = np[1:]
    #     if len(np) > 1:
    #         # Merge the tokens, e.g. good_ideas
    #         np.merge(np.root.tag_, np.text, np.root.ent_type_)
    #     # Iterate over named entities
    #     for ent in doc.ents:
    #         if len(ent) > 1:
    #             # Merge them into single tokens
    #             ent.merge(ent.root.tag_, ent.text, ent.label_)

    # tokens = [token.lemma_ for token in doc if token.isalpha() and token.is_stop == False]



if __name__ == "__main__":
    main()
