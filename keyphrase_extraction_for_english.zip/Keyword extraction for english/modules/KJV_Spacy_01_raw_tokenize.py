"""
source: 01_gensim_prepro.py
purpose: Created dictionary and corpus from raw text after cleaning
author: David Richards

PLAN
* Improve lemmatization (spacy?)
* Add sense2vec
* Autofind book & chapter breaks (treat each as own "topic volume")

"""

# IMPORTS
import os
import string
import gensim
import nltk
from nltk.stem.wordnet import WordNetLemmatizer


# GLOBALS
SCOPE_NAME = 'gen1'
MODELS_DIR = os.path.expanduser('~/Documents/Coding/KJV_Modeler/Models/')


def main():
    # GET TEXT
    verses = nltk.corpus.gutenberg.sents("bible-kjv.txt")  # KJV, parsed by verse, by word

    # verses[3:] skips the KJV title; [2:] skips the 1st 3 items (ch:vs) in each verse (Gen = 3:1471)
    texts = [[word.lower() for word in verse] for verse in verses[3:36]]

    # CREATE & CLEAN DICTIONARY
    # remove punctuation, single-character words, and numbers, stopwords, words used only once
    texts_bu = texts
    lmtzr = WordNetLemmatizer()
    punct = set(string.punctuation)

    texts = [[lmtzr.lemmatize(word) for word in text if word not in punct and len(word) > 1 and not word.isdigit()]
             for text in texts]

    dictionary = gensim.corpora.Dictionary(texts)
    stopword_ids = map(dictionary.token2id.get, stopwords())
    dictionary.filter_tokens(stopword_ids)

    once_ids = [tokenid for tokenid, docfreq in dictionary.dfs.items() if docfreq == 1]
    dictionary.filter_tokens(once_ids)

    dictionary.compactify()

    # SAVE DICTIONARY & CORPUS
    dictionary.save(MODELS_DIR + SCOPE_NAME + '.dict')
    dictionary.save_as_text(MODELS_DIR + SCOPE_NAME + '_dict.txt')
    # pprint(dictionary.token2id)

    corpus = [dictionary.doc2bow(text) for text in texts]
    gensim.corpora.MmCorpus.serialize(MODELS_DIR + SCOPE_NAME + '.mm', corpus)


def stopwords():
    local_stopwords = set('cannot could unto wa'.split())
    return set(nltk.corpus.stopwords.words('english')).union(local_stopwords)


if __name__ == "__main__":
    main()
